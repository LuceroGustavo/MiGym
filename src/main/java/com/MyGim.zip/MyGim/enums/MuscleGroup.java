package com.MyGim.enums;

public enum MuscleGroup {
    BRAZOS,
    PIERNAS,
    PECHO,
    ESPALDA,
    CARDIO,
    ELONGACION
}
