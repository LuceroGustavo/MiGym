package com.MyGim.repositorios;

import com.MyGim.entidades.Rutina;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RutinaRepository extends JpaRepository<Rutina, Long> {
}