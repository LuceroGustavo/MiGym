package com.MyGim;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyGimApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyGimApplication.class, args);
	}

}
